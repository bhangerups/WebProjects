SELECT * FROM studentmanagementsystem.student;
use studentmanagementsystem;
INSERT INTO `studentmanagementsystem`.`student` (`student_id`, `fname`, `lname`, `email`, `password`, `dob`, `mobile_no`, `last_login_date`, `status`, `fees`, `date_of_joining`, `parent_parent_id`) VALUES ('4', 'sina', 'king', 'sina@gmail.com', '123sina', '1993-02-02', '7030503448', '1993-02-05', 'passout', '200', '2019-02-03', '4');
INSERT INTO `studentmanagementsystem`.`student` (`student_id`, `fname`, `lname`, `email`, `password`, `dob`, `mobile_no`, `last_login_date`, `status`, `fees`, `date_of_joining`, `parent_parent_id`) VALUES ('5', 'robin', 'musk', 'robin@gmail.com', 'robi123n', '1998-01-05', '9829674534', '1999-07-03', 'styding', '225', '2004-02-06', '5');
INSERT INTO `studentmanagementsystem`.`student` (`student_id`, `fname`, `lname`, `email`, `password`, `dob`, `mobile_no`, `last_login_date`, `status`, `fees`, `date_of_joining`, `parent_parent_id`) VALUES ('6', 'miller', 'dev', 'miller@gmail.com', 'dev123', '1987-08-03', '9843674534', '1994-06-03', 'passout', '200', '2019-02-03', '2');
INSERT INTO `studentmanagementsystem`.`student` (`student_id`, `fname`, `lname`, `email`, `password`, `dob`, `mobile_no`, `last_login_date`, `status`, `fees`, `date_of_joining`, `parent_parent_id`) VALUES (null, 'merry', 'curry', 'merryr@gmail.com', 'merry123', '1999-07-01', '8877665556', '1995-04-02', 'passout', '200', '1998-02-05', '2');

update student set gender='male';
select * from student;

delimiter //

create procedure sp_getStudent()
begin
 select * from student;
end//
delimiter ;

call sp_getStudent();

 select * from student;
 
 /*============================================================String Operations======================================================*/
 /* display the names of student starting with m */
 
 select fname from student where fname like 'm%';
 
  /* display the names of student ending with with y */

  select fname from student where fname like '%y';
  
  