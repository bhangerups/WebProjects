SELECT * FROM studentmanagementsystem.admin;
use studentmanagementsystem;
select * from admin;
/* procedure */

delimiter //
create procedure sp_getAdmin()
begin
select * from admin;
end //
delimiter ;

call sp_getAdmin();

/*===========================views========================*/

create view vw_students
as
select A.*,B.student_id,B.fees from admin as A
inner join student as B
on A.admin_id=B.student_id;

select * from vw_students;

  /*===========================================================Aggregation function===================================================*/
  select concat("Total Admin :",count(*)) from admin;
  select * from admin;
  
/*

desc admin;
INSERT INTO `studentmanagementsystem`.`admin` (`admin_id`, `fname`, `lname`, `email`, `password`, `dob`, `mobile_no`, `last_login_date`) VALUES ('2', 'bill', 'watson', 'bill@gmail.com', 'bill123', '1997-03-03', '9078563412', '2020-04-02 1:00');
INSERT INTO `studentmanagementsystem`.`admin` (`admin_id`, `fname`, `lname`, `email`, `password`, `dob`, `mobile_no`, `last_login_date`) VALUES ('3', 'bill', 'smith', 'smith@gmail.com', 'smith123', '1997-02-01', '8956442312', '2021-02-07 2:00');

delimiter //
create procedure deleterecord()
begin
declare id int ;
declare fname varchar(20) ;
declare lname varchar (20) ;
declare email varchar (20) ;
declare password varchar(30);
declare dob date ;
declare mobile_no varchar(20) ;
declare last_login varchar(20) ;

declare finished int default 0 ;
declare c1 cursor for select * from admin for update ;
declare continue handler for not found set finished =1 ;
open c1;
cursor_c1_loop:loop
fetch c1 into id,fname,lname,email,password,dob,mobile_no,last_login;
if finished =1 then 
leave cursor_c1_loop;
end if;
delete from admin where fname='bill';
end loop cursor_c1_loop;
close c1;
commit;
end; //
delimiter ;
call deleterecord();
select * from admin;
*/