select * from studentmanagementsystem.teacher;
use studentmanagementsystem;
desc teacher;
alter table teacher add column(gender varchar(20));
update teacher set gender='male' where teacher_id<4; 
select * from teacher;

delimiter //
create procedure sp_getTeacher()
begin 
select * from teacher;
end //
delimiter ;

call sp_getTeacher();

/*=================================================================Aggregation function================================================================*/
                                          
/* Query to perform sum of salary of employees */
                                          
select sum(salary) from teacher;

/*Query to display the name  and salary of teacher who is having maximum salary*/

select fname, lname, max(salary) from teacher;

/*Query to display the name  and salary of teacher who is having minimum salary*/

select fname, lname, min(salary) from teacher;

/*Query to display the name  and salary of teacher who is having average salary*/
select fname, lname, avg(salary) from teacher;


/*===================================================Order by ======================================================================*/

/*Display the names of teacher  in asending order*/

select * from teacher order by fname;

/*Display names of teacher in descending order*/
select * from teacher order by fname desc;

/*===================================================Joins===============================================================================*/
/*inner join*/
select teacher.teacher_id,teacher.fname,student.student_id,student.fname from teacher inner join student on teacher.teacher_id=student.student_id;


commit;
/*======================================Sub-Query=========================================================*/

desc teacher;
select teacher_id,fname from teacher where Admin_admin_id=(select admin_id from admin);

/*========================================================================================================*/

select * from teacher;

/*delimiter //
create procedure insert_using_cursor()
begin 
declare myCursor cursor for select * from teacher for update
end //
delimiter ;
*/

