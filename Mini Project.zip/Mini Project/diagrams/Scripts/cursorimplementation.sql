use studentmanagementsystem;
CREATE TABLE DIM_LOCATION (
IDLocation INT PRIMARY KEY auto_increment,
ZipCode INT ,
Country VARCHAR (20),
State VARCHAR (20),
City VARCHAR (20)
);
INSERT INTO DIM_LOCATION(ZipCode,Country,State,City)
 VALUES
(85086, 'US', 'Arizona', 'Anthem'), (85117, 'US', 'Arizona', 'Apache Jct'), 
(94005, 'US', 'California', 'Brisbane'), (92703, 'US', 'California', 'Bristol'), 
(21163, 'US', 'Maryland', 'Woodstock'), (21648, 'US', 'Maryland', 'Woolford'), 
(122002, 'India', 'Haryana', 'Gurgaon'), (530068, 'India', 'Karnataka', 'Bangalore'), 
(110004, 'India', 'Delhi', 'Delhi'), (400006, 'India', 'Maharashtra', 'Mumbai');

select * from DIM_LOCATION;

/* creating procedure for cursor implementation*/

delimiter //
create procedure deleterecord()
begin
declare a int ;
declare b int ;
declare c VARCHAR (20) ;
declare d VARCHAR (20) ;
declare e VARCHAR (20);
declare finished int default 0;
declare c1 cursor for select * from DIM_LOCATION for update;
declare continue handler for not found set finished =1;
open c1;
cursor_c1_loop:loop
fetch c1 into a,b,c,d,e;
if finished =1 then 
leave cursor_c1_loop;
end if;
delete from DIM_LOCATION where Country='India';
end loop cursor_c1_loop;
close c1;
commit;
end; //
delimiter ;
call deleterecord();
select * from DIM_LOCATION;
