SELECT * FROM studentmanagementsystem.parent;
use studentmanagementsystem;
desc parent;
/*==========================================================insertion=================================================================================*/
INSERT INTO `studentmanagementsystem`.`parent` (`parent_id`, `email`, `fname`, `lname`, `dob`, `mobile_no`, `Admin_admin_id`) VALUES ('6', 'marray@gmail.com', 'marray', 'curry', '1997-01-06', '8877665544', '1');
INSERT INTO `studentmanagementsystem`.`parent` (`parent_id`, `email`, `fname`, `lname`, `dob`, `mobile_no`, `Admin_admin_id`) VALUES ('7', 'lussy@gmail.com', 'lussy', 'sad', '1997-01-06', '8877665544', '1');
INSERT INTO `studentmanagementsystem`.`parent` (`parent_id`, `email`, `fname`, `lname`, `dob`, `mobile_no`, `Admin_admin_id`) VALUES ('8', 'handreygmail.com', 'handrey', 'mical', '1995-02-04', '903422347890', '1');

select * from parent;



/*=================================================================Procedure===========================================================================*/
delimiter //
create procedure sp_getParent()
begin 
select * from parent;
end //
delimiter ;

call sp_getParent();


/* =============================================================Trigger After insert=========================================================*/

desc parent;
create table parent_audit(audit_id int primary key auto_increment,description varchar(100));
desc parent_audit;
select * from parent_audit;

delimiter //
create trigger tr_AfterinsertionParent
 after insert on parent
 for each row
 begin 
insert into parent_audit values(null,concat("A new row inserted in parent table at ",date_format(now(),'%d-%M-%y %n:%i:%s %p')));
 end//
 delimiter ;
/*===========================================================*/

select * from parent;

show triggers;
select * from information_schema.triggers;