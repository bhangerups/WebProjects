console.log("on the script page");
document.getElementById("namevalidation").style.display = "none";
document.getElementById("lastnamevalidation").style.display = "none";
document.getElementById("gendervalidation").style.display = "none";
document.getElementById("emailvalidation").style.display = "none";
document.getElementById("mobilevalidation").style.display = "none";
document.getElementById("passwordvalidation").style.display = "none";
document.getElementById("confirmpasswordvalidation").style.display = "none";

//firstname validation
function namevalidationf() {
  var namev = document.getElementById("firstnameinput").value;
  console.log("name validation called");
  if (namev == "") {
    document.getElementById("namevalidation").style.display = "block";
    document.getElementById("namevalidation").innerHTML =
      "Please enter a first name";
    document.getElementById("firstnameinput").style.borderColor = "red";
    return false;
  } else {
    var filter = /^([a-zA-Z]{2,30})+$/;
    if (!filter.test(namev)) {
      document.getElementById("namevalidation").style.display = "block";
      document.getElementById("namevalidation").innerHTML =
        " only characters are allowed upto 30";
      document.getElementById("firstnameinput").style.borderColor = "red";
      return false;
    } else {
      document.getElementById("namevalidation").style.display = "none";
      document.getElementById("firstnameinput").style.borderColor = "black";
      return true;
    }
  }
}

//lastname validation
function lastnamevalidationf() {
  var namev = document.getElementById("lastnameinput").value;
  console.log("last name validation called");
  if (namev == "") {
    document.getElementById("lastnamevalidation").style.display = "block";
    document.getElementById("lastnamevalidation").innerHTML =
      "Please enter a last name";
    document.getElementById("lastnameinput").style.borderColor = "red";
    return false;
  } else {
    var filter = /^([a-zA-Z]{2,30})+$/;
    if (!filter.test(namev)) {
      document.getElementById("lastnamevalidation").style.display = "block";
      document.getElementById("lastnamevalidation").innerHTML =
        " only characters are allowed upto 30";
      document.getElementById("lastnameinput").style.borderColor = "red";
      return false;
    } else {
      document.getElementById("lastnamevalidation").style.display = "none";
      document.getElementById("lastnameinput").style.borderColor = "black";
      return true;
    }
  }
}

//gender validation
function gendervalidationf() {
  console.log("gender validation called ");
  if (
    document.form.gender[0].checked == false &&
    document.form.gender[1].checked == false
  ) {
    console.log("empty");
    document.getElementById("gendervalidation").style.display = "block";
    document.getElementById("gendervalidation").innerHTML =
      "Please select a gender";
    return false;
  } else {
    console.log("not empty");
    document.getElementById("gendervalidation").style.display = "none";
    document.getElementById("label7").style.borderColor = "black";
    return true;
  }
}

//email validation
function emailvalidationf() {
  var namev = document.getElementById("emailidinput").value;
  console.log("email validation called");
  if (namev == "") {
    document.getElementById("emailvalidation").style.display = "block";
    document.getElementById("emailvalidation").innerHTML =
      "Please enter an email id";
    document.getElementById("emailidinput").style.borderColor = "red";
    return false;
  } else {
    var filter = /^[a-z0-9.!#$%&’+/=?^_`{|}~-]+@[a-z0-9-]+(?:\.[a-z0-9-]+)$/;
    if (!filter.test(namev)) {
      document.getElementById("emailvalidation").style.display = "block";
      document.getElementById("emailvalidation").innerHTML =
        "Please enter valid email id";
      document.getElementById("emailidinput").style.borderColor = "red";
      return false;
    } else {
      document.getElementById("emailvalidation").style.display = "none";
      document.getElementById("emailidinput").style.borderColor = "black";
      return true;
    }
  }
}

//password validation
function passwordvalidationf() {
  var namev = document.getElementById("passwordinput").value;
  console.log("password validation called");
  if (namev == "") {
    document.getElementById("passwordvalidation").style.display = "block";
    document.getElementById("passwordvalidation").innerHTML =
      "Please enter a password";
    document.getElementById("passwordinput").style.borderColor = "red";
    return false;
  } else {
    if (!(namev.length > 8 && namev.length < 20)) {
      document.getElementById("passwordvalidation").style.display = "block";
      document.getElementById("passwordvalidation").innerHTML =
        "password should be 6 to 20 characters";
      document.getElementById("passwordinput").style.borderColor = "red";
      return false;
    } else {
      document.getElementById("passwordvalidation").style.display = "none";
      document.getElementById("passwordinput").style.borderColor = "black";
      return true;
    }
  }
}

//confirmpassword validation
function confirmpasswordvalidationf() {
  var namev = document.getElementById("passwordinput").value;
  var connamev = document.getElementById("confirmpasswordinput").value;
  console.log("confirm password validation called");
  if (namev == "") {
    document.getElementById("confirmpasswordvalidation").style.display =
      "block";
    document.getElementById("confirmpasswordvalidation").innerHTML =
      "Please confirm a password";
    document.getElementById("confirmpasswordinput").style.borderColor = "red";
    return false;
  } else {
    if (!(namev == connamev)) {
      document.getElementById("confirmpasswordvalidation").style.display =
        "block";
      document.getElementById("confirmpasswordvalidation").innerHTML =
        "password should match ";
      document.getElementById("confirmpasswordinput").style.borderColor = "red";
      return false;
    } else {
      document.getElementById("confirmpasswordvalidation").style.display =
        "none";
      document.getElementById("confirmpasswordinput").style.borderColor =
        "black";
      return true;
    }
  }
}

function mobilevalidationf() {
  var namev = document.getElementById("mobilenoinput").value;
  console.log("mobile no validation called");
  if (namev == "") {
    document.getElementById("mobilevalidation").style.display = "none";
    document.getElementById("mobilenoinput").style.borderColor = "black";
    return true;
  } else {
    var filter = /^([0-9]{10,10})+$/;
    if (!filter.test(namev)) {
      document.getElementById("mobilevalidation").style.display = "block";
      document.getElementById("mobilevalidation").innerHTML =
        "only numbers are allowed";
      document.getElementById("mobilenoinput").style.borderColor = "red";
      return false;
    } else {
      document.getElementById("mobilevalidation").style.display = "none";
      document.getElementById("mobilenoinput").style.borderColor = "black";
      return true;
    }
  }
}

//submit validation
function submitvalidationf() {
  console.log("submit validation called");
  if (
    !namevalidationf() ||
    !lastnamevalidationf() ||
    !gendervalidationf() ||
    !emailvalidationf() ||
    !passwordvalidationf() ||
    !confirmpasswordvalidationf() ||
    !mobilevalidationf()
  ) {
    console.log("false");
    return false;
  } else {
    console.log("true");
    //createpopup();
    return true;
  }
}
